Development copies of the SWO will go into this folder, such as owl files.

swo_core.owl file imports the other components. To get the full software ontology get all the files in this folder and load in swo_core.owl and the other will be imported in (may require some import resolving in Protege 3).